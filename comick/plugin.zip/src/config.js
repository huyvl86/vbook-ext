let BASE = "https://comick.live/";
let COMIC = "https://comick.live/comic/";
let SEARCH = "https://comick.live/api/search";
let CHAP = "https://comick.live/api/comics/";
let IMG = "https://cdn1.comicknew.pictures/";
let GENRES = "https://comick.live/_next/data/.d2b57eb7bb777c779aa543b306494dec60b03d1a/search.json";
let LANG = "en";